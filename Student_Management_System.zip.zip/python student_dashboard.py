import mysql.connector
import tkinter as tk
from tkinter import ttk, messagebox
import openpyxl
from openpyxl import Workbook

# -----------------------------------------------------
# DATABASE CONNECTION
# -----------------------------------------------------
def connect_db():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="hyma@123",   # Your MySQL password
        database="student_db"
    )

# -----------------------------------------------------
# VALIDATION FUNCTIONS
# -----------------------------------------------------
def validate_phone(phone):
    return phone.isdigit() and len(phone) == 10

def validate_email(email):
    return "@" in email and ".com" in email
# -----------------------------------------------------
# ADD STUDENT
# -----------------------------------------------------
def add_student():
    if not validate_phone(entry_phone.get()):
        messagebox.showerror("Error", "Phone number must contain exactly 10 digits!")
        return

    if not validate_email(entry_email.get()):
        messagebox.showerror("Error", "Email must contain '@' and '.com'")
        return

    db = connect_db()
    cursor = db.cursor()

    sql = """INSERT INTO students (id, name, age, course, gender, email, phone)
             VALUES (%s, %s, %s, %s, %s, %s, %s)"""
    values = (
        entry_id.get(),
        entry_name.get(),
        entry_age.get(),
        entry_course.get(),
        entry_gender.get(),
        entry_email.get(),
        entry_phone.get()
    )

    cursor.execute(sql, values)
    db.commit()
    db.close()
    messagebox.showinfo("Success", "Student Added Successfully!")
    view_students()

# -----------------------------------------------------
# VIEW STUDENTS
# -----------------------------------------------------
def view_students():
    db = connect_db()
    cursor = db.cursor()
    cursor.execute("SELECT * FROM students")
    result = cursor.fetchall()
    db.close()

    table.delete(*table.get_children())
    for row in result:
        table.insert("", "end", values=row)

# -----------------------------------------------------
# AUTO-FILL DETAILS
# -----------------------------------------------------
def autofill_details(event):
    sid = entry_id.get().strip()
    if sid == "":
        return

    db = connect_db()
    cursor = db.cursor()
    cursor.execute("SELECT name, age, course, gender, email, phone FROM students WHERE id=%s", (sid,))
    result = cursor.fetchone()
    db.close()

    if result:
        entry_name.delete(0, tk.END)
        entry_age.delete(0, tk.END)
        entry_course.delete(0, tk.END)
        entry_gender.delete(0, tk.END)
        entry_email.delete(0, tk.END)
        entry_phone.delete(0, tk.END)

        entry_name.insert(0, result[0])
        entry_age.insert(0, result[1])
        entry_course.insert(0, result[2])
        entry_gender.insert(0, result[3])
        entry_email.insert(0, result[4])
        entry_phone.insert(0, result[5])

# -----------------------------------------------------
# UPDATE STUDENT
# -----------------------------------------------------
def update_student():
    db = connect_db()
    cursor = db.cursor()

    sql = """UPDATE students 
             SET name=%s, age=%s, course=%s, gender=%s, email=%s, phone=%s 
             WHERE id=%s"""

    values = (
        entry_name.get(),
        entry_age.get(),
        entry_course.get(),
        entry_gender.get(),
        entry_email.get(),
        entry_phone.get(),
        entry_id.get()
    )

    cursor.execute(sql, values)
    db.commit()
    db.close()

    if cursor.rowcount > 0:
        messagebox.showinfo("Updated", "Student Updated Successfully!")
        view_students()
    else:
        messagebox.showerror("Error", "Student ID not found!")

# -----------------------------------------------------
# DELETE STUDENT
# -----------------------------------------------------
def delete_student():
    db = connect_db()
    cursor = db.cursor()
    cursor.execute("DELETE FROM students WHERE id=%s", (entry_id.get(),))
    db.commit()
    db.close()

    messagebox.showinfo("Deleted", "Student deleted!")
    view_students()

# -----------------------------------------------------
# DELETE ALL STUDENTS
# -----------------------------------------------------
def delete_all():
    db = connect_db()
    cursor = db.cursor()
    cursor.execute("DELETE FROM students")
    db.commit()
    db.close()
    messagebox.showinfo("Deleted", "All students deleted!")
    view_students()

# -----------------------------------------------------
# SEARCH STUDENT
# -----------------------------------------------------
def search_student():
    keyword = entry_name.get().strip()

    if keyword == "":
        messagebox.showerror("Error", "Enter name to search!")
        return

    db = connect_db()
    cursor = db.cursor()
    cursor.execute("SELECT * FROM students WHERE name LIKE %s", ("%" + keyword + "%",))
    result = cursor.fetchall()
    db.close()

    table.delete(*table.get_children())
    for row in result:
        table.insert("", "end", values=row)

# -----------------------------------------------------
# EXPORT TO EXCEL
# -----------------------------------------------------
def export_excel():
    db = connect_db()
    cursor = db.cursor()
    cursor.execute("SELECT * FROM students")
    result = cursor.fetchall()
    db.close()

    wb = Workbook()
    ws = wb.active
    ws.append(["ID", "Name", "Age", "Course", "Gender", "Email", "Phone"])

    for row in result:
        ws.append(row)

    wb.save("students_export.xlsx")
    messagebox.showinfo("Success", "Data exported to students_export.xlsx")
    # -----------------------------------------------------
# GUI - FULL SCREEN DASHBOARD
# -----------------------------------------------------
root = tk.Tk()
root.title("Student Management System - Dashboard")
root.state("zoomed")  # Full screen

root.config(bg="#F5F7FA")

# LEFT FRAME (FORM)
left_frame = tk.Frame(root, bg="#E3F2FD", width=400)
left_frame.pack(side="left", fill="y")

title = tk.Label(left_frame, text="Student Form", font=("Arial", 20, "bold"),
                 bg="#E3F2FD", fg="#0D47A1")
title.pack(pady=20)

def form_field(label):
    lbl = tk.Label(left_frame, text=label, bg="#E3F2FD", fg="#0D47A1",
                   font=("Arial", 13, "bold"))
    lbl.pack()
    entry = tk.Entry(left_frame, width=30, font=("Arial", 12))
    entry.pack(pady=5)
    return entry

entry_id = form_field("Student ID")
entry_id.bind("<KeyRelease>", autofill_details)

entry_name = form_field("Name")
entry_age = form_field("Age")
entry_course = form_field("Course")
entry_gender = form_field("Gender")
entry_email = form_field("Email")
entry_phone = form_field("Phone")

# BUTTONS
def form_button(text, cmd):
    btn = tk.Button(left_frame, text=text, command=cmd, width=25,
                    bg="#1A73E8", fg="white", font=("Arial", 12, "bold"))
    btn.pack(pady=8)

form_button("Add Student", add_student)
form_button("View Students", view_students)
form_button("Search Student", search_student)
form_button("Update Student", update_student)
form_button("Delete Student", delete_student)
form_button("Delete All Students", delete_all)
form_button("Export to Excel", export_excel)

# RIGHT FRAME (TABLE)
right_frame = tk.Frame(root, bg="white")
right_frame.pack(side="right", fill="both", expand=True)

columns = ("ID", "Name", "Age", "Course", "Gender", "Email", "Phone")

table = ttk.Treeview(right_frame, columns=columns, show="headings", height=25)

for col in columns:
    table.heading(col, text=col)
    table.column(col, width=150)

table.pack(fill="both", expand=True)

view_students()

root.mainloop()